// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
module Two_Digit_Counter(CLK, STARTSTOP, CLEAR, SEG, AN);
  input CLK;
  input STARTSTOP;
  input CLEAR;
  output [6:0]SEG;
  output [7:0]AN;
endmodule
