-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Two_Digit_Counter is
  Port ( 
    CLK : in STD_LOGIC;
    STARTSTOP : in STD_LOGIC;
    CLEAR : in STD_LOGIC;
    SEG : out STD_LOGIC_VECTOR ( 6 downto 0 );
    AN : out STD_LOGIC_VECTOR ( 7 downto 0 )
  );

end Two_Digit_Counter;

architecture stub of Two_Digit_Counter is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
begin
end;
